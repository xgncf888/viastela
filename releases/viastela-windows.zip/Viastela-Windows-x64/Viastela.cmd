@echo off
title Viastela Native Desktop
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0launch-webview2.ps1"
