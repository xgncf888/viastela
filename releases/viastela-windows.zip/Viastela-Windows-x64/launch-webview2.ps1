# Viastela — Windows 10/11 Native WebView2 Thin Shell Host
$ErrorActionPreference = "Stop"
$Port = 4178
$WebRoot = Join-Path $PSScriptRoot "web"

$Listener = New-Object System.Net.HttpListener
$Listener.Prefixes.Add("http://127.0.0.1:$Port/")
$Listener.Start()

$Job = Start-Job -ScriptBlock {
  param($Port, $WebRoot)
  $MimeMap = @{
    ".html" = "text/html; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".svg"  = "image/svg+xml"
    ".png"  = "image/png"
    ".ico"  = "image/x-icon"
    ".woff2"= "font/woff2"
  }
  while ($true) {
    try {
      $Ctx = $Listener.GetContext()
      $Rel = $Ctx.Request.Url.AbsolutePath.TrimStart('/')
      if ([string]::IsNullOrEmpty($Rel)) { $Rel = "index.html" }
      $FilePath = Join-Path $WebRoot $Rel
      if (-not (Test-Path $FilePath -PathType Leaf)) {
        $FilePath = Join-Path $WebRoot "index.html"
      }
      $Ext = [System.IO.Path]::GetExtension($FilePath).ToLower()
      $Ctx.Response.ContentType = if ($MimeMap.ContainsKey($Ext)) { $MimeMap[$Ext] } else { "application/octet-stream" }
      $Bytes = [System.IO.File]::ReadAllBytes($FilePath)
      $Ctx.Response.ContentLength64 = $Bytes.Length
      $Ctx.Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
      $Ctx.Response.OutputStream.Close()
    } catch { break }
  }
}

Start-Process "msedge.exe" -ArgumentList "--app=http://127.0.0.1:$Port/?shell=native --window-size=1320,860"
